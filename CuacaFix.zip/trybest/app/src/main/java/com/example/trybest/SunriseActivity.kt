package com.example.trybest

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class SunriseActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sunrise)
    }
}